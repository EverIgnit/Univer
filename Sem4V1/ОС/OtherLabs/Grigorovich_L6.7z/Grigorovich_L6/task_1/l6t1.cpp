#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <cstring>
using namespace std;

int main(){
    char buffer[]="Текстовая строка для fifo\n";
    char buf[512];
    int w,r;
    bool check = true;
    int fifoUser1 = mkfifo("/home/alina/Рабочий стол/fifouser1", 0777);//указываем путь!
    if(fifoUser1 == -1)
    {
        if(errno!=17){
            cout << "Error fifo user 1: " << errno << endl;
            exit(0);
        }
        check = false;
    } 
    int fifoUser2 = mkfifo("/home/alina/Рабочий стол/fifouser2", 0777);
    if(fifoUser2 == -1)
    {
        if(errno!=17){
            cout << "Error fifo user 1: " << errno << endl;
            exit(0);
        }
        check = false;
    }
    if (check) {
        for(;;) {
            w = open("/home/alina/Рабочий стол/fifouser1", O_WRONLY);
            if(w == -1){
                cout << "Error: " << errno << endl;
            }
            cout << "You: ";
            cin.getline(buf, 256);

            write(w, &buf, 512);
            close(w);
            r = open("/home/alina/Рабочий стол/fifouser2", O_RDONLY);
             if(r  == -1){
                cout << "Error: " << errno << endl;
            }
            if(read(r, &buf, 512) == -1){
                  cout << "Error: " << errno << endl;
            }
            cout << "User: " << buf << endl;
          
            close(r);
        }
    }
    else {
        for(;;) {
            r = open("/home/alina/Рабочий стол/fifouser1", O_RDONLY);
            if(r == -1){
                cout << "Error: " << errno << endl;
            }
            if(read(r, &buf, 512) == -1){
                  cout << "Error: " << errno << endl;
            }
            cout << "User: " << buf << endl;
            close(r);
            w = open("/home/alina/Рабочий стол/fifouser2", O_WRONLY);
            if(w  == -1){
                cout << "Error: " << errno << endl;
            }
            cout << "You: ";
            cin.getline(buf, 256);
            write(w, &buf, 512);
            close(w);
        
           
        }
    }

    unlink("/home/alina/Рабочий стол/fifouser1");
    unlink("/home/alina/Рабочий стол/fifouser2");
    return 0;
}
