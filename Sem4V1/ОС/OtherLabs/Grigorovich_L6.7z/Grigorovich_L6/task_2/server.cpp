#include <sys/ipc.h>
#include <sys/shm.h>
#include <iostream>
#include <semaphore.h>
#include <pthread.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#define SHM_ID 666
#define ACCESS 0666

#define MSG_END 0  
#define MSG_CHATTING 1

#define MAX_LENGTH 120

typedef struct
{
    int type;
    char str[MAX_LENGTH];
    sem_t semServer;
    sem_t semClient;
} message_t;

using namespace std;

int main()
{
    int shmid;
    message_t *msg;
    char s[MAX_LENGTH];

    if ((shmid = shmget(SHM_ID, sizeof(msg), ACCESS | IPC_CREAT)) < 0) {
        cout << "Error" << endl;
        cin.get();
        exit(-1);
    }

    if ((msg = (message_t *) shmat (shmid, 0, 0)) == NULL) {
        cout << "Error" << endl;
        cin.get();
        exit(-1);
    }

    if (sem_init(&(msg->semServer), 0, 0) != 0) {
        cout << "Error" << endl;
        cin.get();
        exit(-1);
    }

    if (sem_init(&(msg->semClient), 0, 0) != 0) {
        cout << "Error" << endl;
        cin.get();
        exit(-1);
    }

    msg->type = 1;

    while(msg->type != MSG_END) {
    if (msg->semServer.__align == 0) {
        continue;
    }
        sem_wait(&(msg->semServer));
        cout << "Server msg: ";
        cin.getline(s, MAX_LENGTH);

        if (strlen(s) < 1) {
            msg->type = MSG_END;
        }

        strncpy(msg->str, s, MAX_LENGTH);
        sem_post(&(msg->semClient));

        while(msg->semServer.__align == 0);
        sem_wait(&(msg->semServer));
        cout << "Client msg: " << msg->str << endl;
        sem_post(&(msg->semServer));
    }

    shmdt (msg);
    if (shmctl(shmid, IPC_RMID, (struct shmid_ds *) 0) < 0) {
        cout << "Error" << endl;
        cin.get();
        exit(-1);
    }

    cout << "Server stoped" << endl;
    cin.get();
    return 0;
}