#include <sys/ipc.h>
#include <sys/shm.h>
#include <iostream>
#include <semaphore.h>
#include <pthread.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#define SHM_ID 666
#define ACCESS 0666   

#define MSG_END 0         
#define MSG_CHATTING 1

#define MAX_LENGTH 120      

typedef struct
{
    int type;
    char str[MAX_LENGTH];
    sem_t semServer;
    sem_t semClient;
} message_t;

#include <errno.h>
using namespace std;

int main()
{
    int shmid;
    message_t *msg;
    char s[MAX_LENGTH];

    if ((shmid = shmget(SHM_ID, sizeof(msg), 0)) < 0) {
         cout << "Error" << endl;
        cin.get();
        exit(-1);
    }

    if ((msg = (message_t *) shmat(shmid, 0, 0)) == NULL) {
          cout << "Error" << endl;
        cin.get();
        exit(-1);
    }

    sem_post(&(msg->semServer));
    while(msg->type != MSG_END) {
        while(msg->semClient.__align == 0);
        sem_wait(&(msg->semClient));
        cout << "Server: " << msg->str << endl;
        cout << "Client: ";
        cin.getline(s, MAX_LENGTH);
        if (strlen(s) < 1) {
            msg->type = MSG_END;
        }

        strncpy(msg->str, s, MAX_LENGTH);

        sem_post(&(msg->semServer));
    }

    shmdt (msg);

    return 0;
}