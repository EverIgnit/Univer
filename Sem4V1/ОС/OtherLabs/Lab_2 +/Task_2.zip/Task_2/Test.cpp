#include <stdio.h>
#include <stdlib.h>
#include <iostream> 

int main(int argc, char const *argv[]) 
{ 

	std::cout<<"It works\n";

	return 0;
}

