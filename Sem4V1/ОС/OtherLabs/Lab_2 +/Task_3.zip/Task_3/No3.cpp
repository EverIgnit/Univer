#include <unistd.h>
#include <stdlib.h>
#include <iostream>
#include <stdio.h>
#include <errno.h>
#include <signal.h>


int main(int argc, char const *argv[]){

	std::cout<< "Enter pid for stop prosecc: ";
	pid_t pid;
	std::cin>>pid;

	if(kill(pid,SIGTSTP) != -0){
		std::cout<<"Something wrong."<< std::endl;
	
	}
	return 0;
}
