#include <stdio.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <locale>
#include <string.h>

#define name "data.txt"

int main(int argc, char const *argv[])
{
	setlocale(LC_CTYPE, "");

	int fd = open(name, O_RDWR);
	if (fd == -1) {
		perror("open file: ");
		return -1;
	}

	void *addr;
	off_t offset;
	size_t length = getpagesize();
	printf("%zu bytes\n", length);

	char *region = (char *)mmap(NULL, length, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	close(fd);
	if (region == MAP_FAILED) { //ошибка отображения
		perror("mmap");
		return -1;
	}
	printf("%s\n", region);
	
	printf("Input key = 14: ");
	int key = 0;
	scanf("%d", &key);

	printf("\nText: \n");
	for (int i = 0; i<strlen(region); i++) {
		int bayt = int(region[i]) ^ key;
		printf("%c", char(bayt));
		region[i] = char(bayt);
	}
	printf("\n");
	munmap(NULL, getpagesize()); //освобождение памяти

	return 0;
}
