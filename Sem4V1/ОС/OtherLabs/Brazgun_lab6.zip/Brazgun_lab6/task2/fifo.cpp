#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include<iostream>
#include <cstring>
#include <unistd.h>/// close()
#include <string.h>
#include <semaphore.h>
using namespace std;

#define FIFO_NAME "my_named_pipe"
#define BUF_SIZE 512
#define SEMAPHORE_NAME "/my_semaphore"

int fd;
bool flag=true;
sem_t *semaphore;

void makeFifo(){
    if(mkfifo(FIFO_NAME,0777)==-1)
      flag=false;
    else cout<<FIFO_NAME<<"  is created"<<endl;

    if((fd=open(FIFO_NAME,O_RDWR))==-1)
        cout<<"Error open fifo"<<endl;
    else cout<<"file is open"<<endl;
}

void func(){

    char buf1[BUF_SIZE];
    while(true)
    {
    memset(buf1,'\0',BUF_SIZE);
    sem_wait(semaphore);
    if(read(fd,buf1,BUF_SIZE-1)!=-1)
    {
        if(strcmp(buf1,"EXIT")==0)
        {
            cout<<"Your Interlocutor broke the connection"<<endl;
            sem_post(semaphore);
            break;
        }
        cout<<"Interlocutor: "<<buf1<<endl;
    }else cout<<"error read"<<endl;

    cout<<"Input your message(enter <EXIT> to exit):"<<endl;
    string message;
    cin>>message;
    if(write(fd,message.c_str(),message.size())==-1)
    {
        cout<<"error write"<<endl;
    }
    sem_post(semaphore);
    if(message == "EXIT")
        break;
    sleep(1);
    }
}


int main(){
    
    makeFifo();

    if((semaphore = sem_open(SEMAPHORE_NAME,O_CREAT,0666,1))==SEM_FAILED)
    {
        cout<<"semaphore failed"<<endl;
    }
    else cout<<" semaphore create or open"<<endl;

    if(flag)
    {

        string message;
        cout<<"Input your message(enter <EXIT> to exit):"<<endl;
        sem_wait(semaphore);
        cin>>message; 
        if(write(fd,message.c_str(),message.size())==-1)
        cout<<"error write 1"<<endl;
        sem_post(semaphore);
        if(message=="EXIT")
        return 0;
    }
    sleep(1);
    func();
    sem_unlink(SEMAPHORE_NAME);
    sem_close(semaphore);
    close(fd);
    remove(FIFO_NAME);    
}